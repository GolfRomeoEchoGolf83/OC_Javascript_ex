// Initialiser le constructeur
var Robot = {
    init: function robot(name, life, speed, position) {
        this.name = name;
        this.life = 100;
        this.speed = 3;
        this.position = [0, 0];
    },


    sePresenter: function () {
        // code pour se presenter
        var description = "Bonjour, je m'appelle " + this.name + ". J'ai " + this.life + " points de vie. Je me déplace à " + this.speed + " cases par seconde. Je suis aux coordonnées (" + this.position + ").";
        return description;
    },

    seDeplacer: function () {
        // code pour se deplacer
        var direction = prompt("choisi une direction : haut / bas / droite / gauche");
        var nombreCases = 0;

        if (direction.toLowerCase() === "gauche") {
            nombreCases = Number(prompt("choisis un nombre de cases"));
            alert("le robot va se déplacer vers la gauche de " + nombreCases + " cases.");


        } else if (direction.toLowerCase() === "haut") {
            nombreCases = Number(prompt("choisis un nombre de cases"));
            alert("le robot va se déplacer vers le haut de " + nombreCases + " cases.");

        } else if (direction.toLowerCase() === "droite") {
            nombreCases = Number(prompt("choisis un nombre de cases"));
            alert("le robot va se déplacer vers la droite de " + nombreCases + " cases.");

        } else if (direction.toLowerCase() === "bas") {
            nombreCases = Number(prompt("choisis un nombre de cases"));
            alert("le robot va se déplacer vers le bas de " + nombreCases + " cases.");

        } else {
            alert("la direction renseignée est erronnée. Choisis haut / bas / droite ou gauche.");
        }


        if (direction === "gauche") {
            var caseDeplacement = -nombreCases;
            console.log(caseDeplacement);

        } else if (direction === "bas") {
            caseDeplacement = -nombreCases
            console.log(nombreCases);

        } else {
            console.log(nombreCases);
        }

    }
};

// initialisation des 4 robots
var robotSquad = [];
var robot = "";

var robot1 = Object.create(Robot);
var robot2 = Object.create(Robot);
var robot3 = Object.create(Robot);
var robot4 = Object.create(Robot);

robot1.init("Alpha");
robot2.init("Bravo");
robot3.init("Charlie");
robot4.init("Delta");

robotSquad.push(robot1, robot2, robot3, robot4);

// test de l'itération des données pour les robots 
console.log(robot1, robot2, robot3, robot4);
console.log(robotSquad);

// présentations des robots
for (var i = 0; i < robotSquad.length; i++) {
    console.log(robotSquad[i].sePresenter());
}

for (var i = 0; i < robotSquad.length; i++) {
    robotSquad[i].seDeplacer();

}